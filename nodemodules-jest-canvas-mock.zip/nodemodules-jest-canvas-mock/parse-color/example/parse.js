var parse = require('../');
console.log(parse(process.argv[2]));
