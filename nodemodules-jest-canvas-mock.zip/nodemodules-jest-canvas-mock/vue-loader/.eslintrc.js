module.exports = {
  root: true,
  extends: ['plugin:vue-libs/recommended'],
  rules: {
    indent: 'off',
    'space-before-function-paren': 'off'
  }
}
